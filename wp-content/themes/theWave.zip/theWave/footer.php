<footer>
    <div class="container"> 
        <div class="d-flex mb-3">
            <p class="fw-bold mb-0 me-4">The Wave</p>
            <p class="text-muted mb-0">The Team</p>
        </div>
    </div>
</footer>
    <?php wp_footer(); ?>
  </body>
</html>